#!/usr/bin/env bash
python bin2c.py index.htm -o index_htm_gz
python bin2c.py favicon.ico -o favicon_ico_gz